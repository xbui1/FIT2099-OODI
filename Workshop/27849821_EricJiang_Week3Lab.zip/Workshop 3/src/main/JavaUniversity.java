/**
 * Eric Jiang
 * 27849821
 */


package main;

import main.UniversityDriver;

public class JavaUniversity {
    public UniversityDriver universityDriver;




    public void main(String[] args){

    }

}