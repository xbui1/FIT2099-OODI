/**
 * Eric Jiang
 * 27849821
 */


package main;

import main.University;

public class UniversityDriver {
    public University university;

    public static void main(String[] args) {
        University university = new University();
        university.printStatus();
    }

}